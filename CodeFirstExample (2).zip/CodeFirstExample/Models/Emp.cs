﻿namespace CodeFirstExample.Models
{
    public class Emp
    {
        public long empid { get; set; }
        public string empname { get; set; }
        public int salary { get; set; }

        public string designation { get; set; }

    }
}
