﻿namespace CodeFirstExample.Models
{
    public class FileUpload
    {
        public IFormFile FormFile { set; get; }
    }
}
