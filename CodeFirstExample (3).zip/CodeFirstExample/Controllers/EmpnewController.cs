﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CodeFirstExample.Models;

namespace CodeFirstExample.Controllers
{
    public class EmpnewController : Controller
    {
        private readonly MyDbContext _context;

        public EmpnewController(MyDbContext context)
        {
            _context = context;
        }

        // GET: Empnew
        public async Task<IActionResult> Index()
        {
              return _context.emps != null ? 
                          View(await _context.emps.ToListAsync()) :
                          Problem("Entity set 'MyDbContext.emps'  is null.");
        }

        // GET: Empnew/Details/5
        public async Task<IActionResult> Details(long? id)
        {
            if (id == null || _context.emps == null)
            {
                return NotFound();
            }

            var emp = await _context.emps
                .FirstOrDefaultAsync(m => m.empid == id);
            if (emp == null)
            {
                return NotFound();
            }

            return View(emp);
        }

        // GET: Empnew/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Empnew/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("empid,empname,salary,designation")] Emp emp)
        {
            if (ModelState.IsValid)
            {
                _context.Add(emp);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(emp);
        }

        // GET: Empnew/Edit/5
        public async Task<IActionResult> Edit(long? id)
        {
            if (id == null || _context.emps == null)
            {
                return NotFound();
            }

            var emp = await _context.emps.FindAsync(id);
            if (emp == null)
            {
                return NotFound();
            }
            return View(emp);
        }

        // POST: Empnew/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(long id, [Bind("empid,empname,salary,designation")] Emp emp)
        {
            if (id != emp.empid)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(emp);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmpExists(emp.empid))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(emp);
        }

        // GET: Empnew/Delete/5
        public async Task<IActionResult> Delete(long? id)
        {
            if (id == null || _context.emps == null)
            {
                return NotFound();
            }

            var emp = await _context.emps
                .FirstOrDefaultAsync(m => m.empid == id);
            if (emp == null)
            {
                return NotFound();
            }

            return View(emp);
        }

        // POST: Empnew/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(long id)
        {
            if (_context.emps == null)
            {
                return Problem("Entity set 'MyDbContext.emps'  is null.");
            }
            var emp = await _context.emps.FindAsync(id);
            if (emp != null)
            {
                _context.emps.Remove(emp);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EmpExists(long id)
        {
          return (_context.emps?.Any(e => e.empid == id)).GetValueOrDefault();
        }
    }
}
