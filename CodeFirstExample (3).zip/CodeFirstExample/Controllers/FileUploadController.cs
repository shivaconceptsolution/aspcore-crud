﻿using Microsoft.AspNetCore.Mvc;
using CodeFirstExample.Models;
using Microsoft.Extensions.Hosting.Internal;

namespace CodeFirstExample.Controllers
{
    public class FileUploadController : Controller
    {
        private IWebHostEnvironment Environment;
        public FileUploadController(IWebHostEnvironment _environment)

        {

            Environment = _environment;

        }
        public IActionResult Index()
        {
            return View(new FileUpload());
        }
        [HttpPost]
        public IActionResult Index(FileUpload obj)
        {
            var uniqueFileName = GetUniqueFileName(obj.FormFile.FileName);
            var uploads = Path.Combine(Environment.WebRootPath, "uploads");
            var filePath = Path.Combine(uploads, uniqueFileName);
            obj.FormFile.CopyTo(new FileStream(filePath, FileMode.Create));
            ViewBag.data = uniqueFileName;
            return View("showfile");
        }
        private string GetUniqueFileName(string fileName)
        {
            fileName = Path.GetFileName(fileName);
            return Path.GetFileNameWithoutExtension(fileName)
                      + "_"
                      + Guid.NewGuid().ToString().Substring(0, 4)
                      + Path.GetExtension(fileName);
        }
    }
}
