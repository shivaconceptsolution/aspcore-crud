﻿using CodeFirstExample.Models;
using Microsoft.AspNetCore.Mvc;

namespace CodeFirstExample.Controllers
{
    public class AjaxExampleController : Controller
    {
        private readonly MyDbContext _context;

        public AjaxExampleController(MyDbContext context)
        {
            _context = context;
        }
        public  IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public JsonResult Ajaxcode(IFormCollection obj)
        {
            Student student = new Student();
           // student.Id = Convert.ToInt32(obj["ID"]);
            student.Name = obj["Name"].ToString();
            student.Age = Convert.ToInt32(obj["Age"]);
           // return Json(new { msg = "Insert Sucess" });
              try
               {

                   _context.Add(student);
                   _context.SaveChanges();
                   return Json(new { msg = "Insert Sucess" });
               }
               catch(Exception ex)
               {
                   return Json(new { msg = "Insert Fail" });
               }
        }
    }
}
