﻿using CodeFirstExample.Models;
using Microsoft.AspNetCore.Mvc;

namespace CodeFirstExample.Controllers
{
    public class AjaxsearchController : Controller
    {
        private readonly MyDbContext _context;

        public AjaxsearchController(MyDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Searchdata(String id)
        {
            ViewBag.data = id;
            var s = from c in _context.students where c.Name.StartsWith(id) select c;
            return View(s.ToList());
        }
    }
}
