﻿using Microsoft.AspNetCore.Mvc;

namespace CodeFirstExample.Controllers
{
    public class SecondController : Controller
    {
        public IActionResult Index()
        {
            TempData.Keep();
            return View();
        }
    }
}
