﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CodeFirstExample.Models
{
    public class Emp
    {
        public long empid { get; set; }
        [Required]
        public string empname { get; set; }

        [Column("empsalary")]
        [Range(10000, 50000)]
        public int salary { get; set; }
        [Column("designation")]
        public string designation { get; set; }

        public string email { get; set; }
        [StringLength(10)]
        public string mobile { get; set; }

    }
}
