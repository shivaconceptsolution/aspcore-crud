﻿using Microsoft.AspNetCore.Mvc;

namespace CodeFirstExample.Controllers
{
    public class FirstController : Controller
    {
        public IActionResult Index()
        {
            ViewData["key"] = 1000;
            ViewBag.Msg = 2000;
            TempData.Keep();
            TempData["key"] = 3000;
          
            return RedirectToAction("Index","Second");
            //return View();

        }
    }
}
