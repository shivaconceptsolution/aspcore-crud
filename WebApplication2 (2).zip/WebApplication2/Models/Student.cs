﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    public class Student
    {
        [Key]
        public long rno { get; set; }
        public string? name { get; set; }
    }
}
