﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private readonly StudentDbContext _db;
        public StudentsController(StudentDbContext _db) {
            this._db = _db;

        }
        [HttpGet]
          public async Task<ActionResult<IEnumerable<Student>>> GetStudents()
            {
            return await _db.Students.ToListAsync();
            }
        [HttpGet("{id}")]
        public async Task<ActionResult<Student>> GetStudentByRno(long id)
        {
            var studata= await _db.Students.FindAsync(id);
            if(studata==null)
            {
                return NotFound();
            }
            return studata;
        }
    }
}
