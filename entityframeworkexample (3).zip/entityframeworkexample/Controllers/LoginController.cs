﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace entityframeworkexample.Models.DB
{
    public class LoginController : Controller
    {
        private readonly CollegeerpContext _context;

        public LoginController(CollegeerpContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
          
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Index(Register obj)
        {
            var s = await (from c in _context.Registers where c.username.Equals(obj.username) && c.password.Equals(obj.password) select c).FirstOrDefaultAsync();
            if (s == null)
            {
                ViewBag.data = "LOgin fail";
                return View();
            }
            else
            {
               return RedirectToAction("Index","Students");
            }
            
        }
    }
}
