﻿using entityframeworkexample.Models.DB;
using Microsoft.AspNetCore.Mvc;

namespace entityframeworkexample.Controllers
{
    public class RegController : Controller
    {
        private readonly CollegeerpContext _context;

        public RegController(CollegeerpContext context)
        {
            _context = context;
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(Register obj)
        {
            if (ModelState.IsValid)
            {
                _context.Registers.Add(obj);
                await _context.SaveChangesAsync();
                ViewBag.data = "Registration successfully";
            }
            return View(obj);
        }

    }
}
