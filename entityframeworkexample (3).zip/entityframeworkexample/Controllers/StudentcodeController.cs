﻿using entityframeworkexample.Models.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace entityframeworkexample.Controllers
{
    public class StudentcodeController : Controller
    {
        private CollegeerpContext db;
        public StudentcodeController(CollegeerpContext db)
        {
            this.db = db;
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(Student obj)
        {
            db.Students.Add(obj);
            await db.SaveChangesAsync();
            ViewBag.Data = "Data Inserted Suceesfully";
            return RedirectToAction("Index");
        }
        public async Task<IActionResult> Index()
        {
            var s = await db.Students.ToListAsync();  // select * from students
            return View(s);
        }
        public async Task<IActionResult> EditStudent(int? id)
        {
            var s = await db.Students.FindAsync(id);  // select * from students
            return View(s);
        }
        [HttpPost]
        public async Task<IActionResult> EditStudent(Student obj)
        {
            db.Entry(obj).State = EntityState.Modified;
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }
        public async Task<IActionResult> DeleteStudent(int? id)
        {
            var s = await db.Students.FindAsync(id);  // select * from students
            return View(s);
        }
        [HttpPost]
        public async Task<IActionResult> DeleteStudent(Student obj)
        {
            db.Students.Remove(obj);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }
    }
}
