﻿namespace entityframeworkexample.Models.DB
{
    public class Register
    {
        public string? username { get; set; }
        public string? password { get; set; }
        public string? email { get; set; }
        public string? mobile { get; set; }


    }
}
