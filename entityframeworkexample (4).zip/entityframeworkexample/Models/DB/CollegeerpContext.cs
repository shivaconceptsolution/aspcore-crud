﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace entityframeworkexample.Models.DB;

public partial class CollegeerpContext : DbContext
{
    public CollegeerpContext()
    {
    }

    public CollegeerpContext(DbContextOptions<CollegeerpContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Student> Students { get; set; }
    public virtual DbSet<Register> Registers { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Student>(entity =>
        {
            entity.HasKey(e => e.Rno).HasName("PK_tbl_student");

            entity.ToTable("Student");

            entity.Property(e => e.Rno)
                .ValueGeneratedNever()
                .HasColumnName("rno");
            entity.Property(e => e.Branch)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("branch");
            entity.Property(e => e.Fees).HasColumnName("fees");
            entity.Property(e => e.Sname)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("sname");
        });
        modelBuilder.Entity<Register>(entity =>
        {
            entity.HasKey(e => e.username).HasName("PK_tbl_register");

            entity.ToTable("Register");

            entity.Property(e => e.username)
                 .HasMaxLength(50)
                 .IsUnicode(false)
                 .HasColumnName("username");
            entity.Property(e => e.password)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("password");
           
            entity.Property(e => e.email)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("email");
            entity.Property(e => e.mobile)
              .HasMaxLength(10)
              .IsUnicode(false)
              .HasColumnName("mobile");

        });

        // OnModelCreatingPartial(modelBuilder);
    }

   // partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
